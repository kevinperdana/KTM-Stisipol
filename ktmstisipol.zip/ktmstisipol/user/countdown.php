<div class="header">
  <div class="content">
    <h2>COMING SOON</h2>
    <!--<div class="countdown">00 : 00 : 00 : 00</div>-->
    <div class="wrapper">
      <div class="countdown" data-date="18-12-2022" data-time="24:00">
        <div class="day"><span class="num"></span><span class="word"></span></div>
        <div class="hour"><span class="num"></span><span class="word"></span></div>
        <div class="min"><span class="num"></span><span class="word"></span></div>
        <div class="sec"><span class="num"></span><span class="word"></span></div>
      </div>
    </div>

  </div>
</div>
<script src="../templates/js/countdown.js"></script>
<script src="../templates/js/init.js"></script>