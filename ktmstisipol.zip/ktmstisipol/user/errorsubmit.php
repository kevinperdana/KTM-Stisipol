<!DOCTYPE html>
<!-- saved from url=(0117)https://site167442.nicepage.io/?version=b01c0e46-5f3f-4c34-b22a-cc6105c5ad4a&uid=0cb57cf9-13d9-440a-a3ea-59fa48ebe52a -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl">
  <!-- HEAD -->
  <?php
    include "head.php";
  ?>
  <!-- END HEAD -->
  <body
    data-home-page="Page-2.html" data-home-page-title="Page 2" class="u-body u-xl-mode" data-lang="en">
    <!-- HEADER -->
    <?php
      include "header.php";
    ?>
    <!-- END HEADER -->

      <!-- ERROR -->
      <section class="u-align-left u-black u-clearfix u-section-5" id="carousel_ccf3">
         <div class="u-clearfix u-sheet u-valign-middle u-sheet-2">
          <div class="u-align-left u-container-style u-group u-group-1">
            <div class="u-container-layout u-valign-middle u-container-layout-1">
              <h2 class="u-text u-text-1">Submit Error</h2>
              <p class="u-text u-text-2">Email already registered.</p>
            </div>
          </div>
        </div>
      </section>

    <section class="u-backlink u-clearfix" style="background-color:#fffb00">
      <p class="u-text">
        <span style="font-size: 14px;">Copyright 2022</span>
      </p>
    </section>
  
<style>.u-disable-duration * {transition-duration: 0s !important;}</style><script>mendeleyWebImporter = {
  downloadPdfs(e,t) { return this._call('downloadPdfs', [e,t]); },
  open() { return this._call('open', []); },
  setLoginToken(e) { return this._call('setLoginToken', [e]); },
  _call(methodName, methodArgs) {
    const id = Math.random();
    window.postMessage({ id, token: '0.08873609553305739', methodName, methodArgs }, 'https://site167442.nicepage.io');
    return new Promise(resolve => {
      const listener = window.addEventListener('message', event => {
        const data = event.data;
        if (typeof data !== 'object' || !('result' in data) || data.id !== id) return;
        window.removeEventListener('message', listener);
        resolve(data.result);
      });
    });
  }
};</script></body></html>