<?php
  session_start();
  //$userid = $_SESSION['userid'];
  //$email = $_SESSION['email'];
  $email = $_GET["email"];
  
  require('../plugins/fpdf/fpdf.php');
  include "../config/koneksi.php";

  $result = mysqli_query($conn, "SELECT * FROM tb_users WHERE email='$email'");
            $row = mysqli_fetch_array($result);
            $userid = $row['userid'];
            $category = $row['category'];
            $namebib = $row['namebib'];
            $nourut = $row['nourut'];
            $nameemergency = $row['nameemergency'];
            $bloodtype = $row['bloodtype'];
            if($bloodtype == "a"){
              $bloodtypefixed = "A";
            } else if($bloodtype == "b"){
              $bloodtypefixed = "B";
            } else if($bloodtype == "ab"){
              $bloodtypefixed = "AB";
            } else if($bloodtype == "o"){
              $bloodtypefixed = "O";
            } else if($bloodtype == "Unknown"){
              $bloodtypefixed = "UNKNOWN";
            }

            $phone = $row['phone'];
            $phoneemergency = $row['phoneemergency'];
  
  if($category == "Umum"){
    $bibbackround = "../templates/kepri10k/bibumum.jpg";
  } else if($category == "Pelajar"){
    $bibbackround = "../templates/kepri10k/bibpelajar.jpg";
  } else if($category == "Veteran"){
    $bibbackround = "../templates/kepri10k/bibveteran.jpg";
  }

  $pdf = new FPDF('L','mm','A5');
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);
  //$pdf->Image('../templates/kepri10k/bibdesign.png',0,0,210,148);
  $pdf->Image($bibbackround,0,0,210,148);
  $pdf->SetFont('Arial','B',95);
  $pdf->SetTextColor(0,0,0);
  $pdf->Cell(0,120,$nourut,0,0,'C');
  $pdf->Ln(16);
  //$pdf->SetFont('Arial','B',40);
  //$pdf->SetTextColor(0,0,0);
  $pdf->SetFont('Arial','B',14);
  $pdf->Cell(0,120,$namebib,0,0,'C');
  //$pdf->Cell(0,80,$namebib,0,0,'C');
  // PHONE
  $pdf->SetFont('Arial','B',13);
  $pdf->SetTextColor(255,255,255);
  //$pdf->SetX(100);
  $pdf->SetXY(62,119.5);
  $pdf->Cell(60,10,$nameemergency,0,0,'L');
  $pdf->SetXY(62,-23);
  $pdf->Cell(80,10,$phoneemergency,0,0,'L');
  $pdf->SetXY(62,-17.2);
  $pdf->Cell(80,10,$bloodtypefixed,0,0,'L');
  $pdf->Output();
?>