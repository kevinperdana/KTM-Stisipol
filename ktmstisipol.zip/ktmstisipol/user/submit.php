<!DOCTYPE html>
<!-- saved from url=(0117)https://site167442.nicepage.io/?version=b01c0e46-5f3f-4c34-b22a-cc6105c5ad4a&uid=0cb57cf9-13d9-440a-a3ea-59fa48ebe52a -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl">
  <!-- HEAD -->
  <?php
    include "head.php";
  ?>
  <!-- END HEAD -->
  <body
    data-home-page="Page-2.html" data-home-page-title="Page 2" class="u-body u-xl-mode" data-lang="en">
    <!-- HEADER -->
    <?php
      include "header.php";
    ?>
    <!-- END HEADER -->

    <?php
      include "../config/koneksi.php";

      if(isset($_POST["submit"])){
        $email = $_POST["email"];
        $checkemail = mysqli_query($conn, "SELECT email FROM tb_users WHERE email='$email'");
        if(mysqli_num_rows($checkemail) == 1){
          ?>
          <script type="text/javascript">
            window.location = "errorsubmit.php";
          </script>
          <?php
        } else if(mysqli_num_rows($checkemail) == 0) {
          //if(isset($_POST["submit"])){
            $nama = $_POST["nama"];
            $email = $_POST["email"];
            $gender = $_POST["gender"];
            $placeofbirth = $_POST["placeofbirth"];
            $birthdate = $_POST["birthdate"];
            $phone = $_POST["phone"];
            $alamat = $_POST["alamat"];
            $city = $_POST["city"];
            $province = $_POST["province"];
            $nationality = $_POST["nationality"];
            $bloodtype = $_POST["bloodtype"];
            $idnumbertype = $_POST["idnumbertype"];
            $idnumber = $_POST["idnumber"];
            $kategori = $_POST["kategori"];
            $nameemergency = $_POST["nameemergency"];
            $phoneemergency = $_POST["phoneemergency"];
            $rbjantung = $_POST['rbjantung'];
            $rbhipertensi = $_POST['rbhipertensi'];
            $rbkronik = $_POST['rbkronik'];
            $rbepilepsi = $_POST['rbepilepsi'];
            $rbasma = $_POST['rbasma'];
            $rbasuransi = $_POST['rbasuransi'];
            $rbalergi = $_POST['rbalergi'];
            $alergi = $_POST['alergi'];
            $namebib = $_POST["namebib"];
            $ukuranbaju = $_POST["ukuranbaju"];
            $payment = $_FILES['file']['name'];
    
            $hitungnourut = mysqli_query($conn, "SELECT nourut + 1 AS Next_No_Urut FROM tb_users WHERE category='$kategori' 
            ORDER BY nourut DESC LIMIT 1");
            $hasilhitungnourut = mysqli_fetch_array($hitungnourut);
            $nextnourut = $hasilhitungnourut['Next_No_Urut'];

            /*echo "$nama";
            echo "$email";
            echo "$gender";
            echo "$placeofbirth";
            echo "$birthdate";
            echo "$phone";
            echo "$alamat";
            echo "$city";
            echo "$province";
            echo "$nationality";
            echo "$bloodtype";
            echo "$idnumbertype";
            echo "$idnumber";
            echo "$kategori";
            echo "$nameemergency";
            echo "$phoneemergency";
            echo "$rbjantung";
            echo "$rbhipertensi";
            echo "$rbkronik";
            echo "$rbepilepsi";
            echo "$rbasma";
            echo "$rbasuransi";
            echo "$rbalergi";
            echo "$alergi";
            echo "$namebib";
            echo "$ukuranbaju";
            echo "$nextnourut";*/
  
            $target_dir = "upload/";
            $target_file = $target_dir . basename($_FILES["file"]["name"]);
    
            // Remove Space File Name
            $strippedFileName = strtolower(str_replace(" ", "", $payment));
    
            // Select file type
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    
            // Valid file extensions
            $extensions_arr = array("jpg","jpeg","png","gif");
    
            // Check extension
            if(in_array($imageFileType,$extensions_arr) ){
              // Upload file
              if(move_uploaded_file($_FILES['file']['tmp_name'],$target_dir.$strippedFileName)){
                $urlPayment = $strippedFileName;
                //echo "$urlPayment";
                // Insert record
                //$query = "insert into images(name) values('".$name."')";
                //mysqli_query($con,$query);
                $sql = "INSERT INTO tb_users (nama, email, gender, placeofbirth, birthdate, phone, alamat, city, province, nationality, bloodtype, idnumbertype, idnumber, category, nameemergency, phoneemergency, riwayatjantung, riwayathipertensi, riwayatkronik, riwayatepilepsi, riwayatasma, riwayatasuransi, riwayatalergi, alergi, namebib, ukuranbaju, nourut, urlpayment)
                    VALUES ('$nama', '$email', '$gender', '$placeofbirth', '$birthdate', '$phone', '$alamat', '$city', '$province', '$nationality', '$bloodtype', '$idnumbertype', '$idnumber', '$kategori', '$nameemergency', '$phoneemergency', '$rbjantung', '$rbhipertensi', '$rbkronik', '$rbepilepsi', '$rbasma', '$rbasuransi', '$rbalergi', '$alergi', '$namebib', '$ukuranbaju', '$nextnourut', '$strippedFileName')";
              }
    
            }
    
            if (mysqli_query($conn, $sql)) {
              ?>
              <!-- THANK YOU -->
              <section class="u-align-left u-black u-clearfix u-section-5" id="carousel_ccf3">
                <div class="u-clearfix u-sheet u-valign-middle u-sheet-2">
                  <div class="u-align-left u-container-style u-group u-group-1">
                    <div class="u-container-layout u-valign-middle u-container-layout-1">
                      <h2 class="u-text u-text-1">Thank You</h2>
                      <p class="u-text u-text-2">Your reservation is reviewed.</p>
                    </div>
                  </div>
                </div>
              </section>
              <?php
            } else {
              ?>
              <!-- ERROR -->
              <section class="u-align-left u-black u-clearfix u-section-5" id="carousel_ccf3">
                <div class="u-clearfix u-sheet u-valign-middle u-sheet-2">
                  <div class="u-align-left u-container-style u-group u-group-1">
                    <div class="u-container-layout u-valign-middle u-container-layout-1">
                      <h2 class="u-text u-text-1">Submit Error</h2>
                      <p class="u-text u-text-2">There was an error trying to send your application.</p>
                    </div>
                  </div>
                </div>
              </section>
              <?php
            }
    
            $conn->close();
          }
        }
      //}
    ?>

    <section class="u-backlink u-clearfix" style="background-color:#fffb00">
      <p class="u-text">
        <span style="font-size: 14px;">Copyright 2022</span>
      </p>
    </section>
  
<style>.u-disable-duration * {transition-duration: 0s !important;}</style><script>mendeleyWebImporter = {
  downloadPdfs(e,t) { return this._call('downloadPdfs', [e,t]); },
  open() { return this._call('open', []); },
  setLoginToken(e) { return this._call('setLoginToken', [e]); },
  _call(methodName, methodArgs) {
    const id = Math.random();
    window.postMessage({ id, token: '0.08873609553305739', methodName, methodArgs }, 'https://site167442.nicepage.io');
    return new Promise(resolve => {
      const listener = window.addEventListener('message', event => {
        const data = event.data;
        if (typeof data !== 'object' || !('result' in data) || data.id !== id) return;
        window.removeEventListener('message', listener);
        resolve(data.result);
      });
    });
  }
};</script></body></html>