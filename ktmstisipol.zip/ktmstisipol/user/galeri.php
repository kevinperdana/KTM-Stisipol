<!DOCTYPE html>
<!-- saved from url=(0117)https://site167442.nicepage.io/?version=b01c0e46-5f3f-4c34-b22a-cc6105c5ad4a&uid=0cb57cf9-13d9-440a-a3ea-59fa48ebe52a -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl">
  <!-- HEAD -->
  <?php
    include "head.php";
  ?>
  <!-- END HEAD -->
  <body
    data-home-page="Page-2.html" data-home-page-title="Page 2" class="u-body u-xl-mode" data-lang="en">
    <!-- HEADER -->
    <?php
      include "header.php";
    ?>
    <!-- END HEADER -->

    <!-- TEASER -->
    <section class="u-align-center u-clearfix u-palette-1-base u-section-9" id="carousel_f3ba" style="background-color: #000; text-align:center">
      <div class="u-clearfix u-sheet u-valign-middle-xs u-sheet-1">
        <h2 class="u-text u-text-default u-text-1">TEASER</h2>
        <div class="u-align-center u-expanded-width-sm u-expanded-width-xs u-video u-video-1">
          <div class="embed-responsive embed-responsive-1">
            <!--<iframe style="left: 0;width: 100%;height: 100%;" class="embed-responsive-item" src="https://www.youtube.com/embed/tgbNymZ7vqY" frameborder="0" allowfullscreen=""></iframe>-->
            <video width="100%" controls style="left: 0;width: 100%;height: 100%;">
              <source src="../templates/video/teaser.mp4" type="video/mp4">
              <source src="../templates/video/teaser.mp4" type="video/ogg"> Your browser does not support the video tag.
            </video>
            
          </div>
        </div>
      </div>
    </section>

    <!-- GALERI -->
    <section class="u-align-center u-clearfix u-palette-1-base u-section-8" id="sec-86a2" style="background-color: #000">
      <div class="u-clearfix u-sheet u-valign-middle-xs u-sheet-1">
        <h2 class="u-text u-text-default u-text-1">GALERI</h2>
        <div class="u-expanded-width u-gallery u-layout-grid u-lightbox u-show-text-on-hover u-gallery-1" data-pswp-uid="1">
          <div class="u-gallery-inner u-gallery-inner-1">
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="0" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri1.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-1">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="1" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri2.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-2">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="2" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri3.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-3">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="3" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri4.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-4">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="4" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri5.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-5">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
            <div class="u-effect-fade u-gallery-item" data-pswp-item-id="5" data-gallery-uid="1">
              <div class="u-back-slide">
                <img class="u-back-image u-expanded" src="../templates/galeri/galeri6.jpeg">
              </div>
              <div class="u-over-slide u-shading u-over-slide-6">
                <h3 class="u-gallery-heading"></h3>
                <p class="u-gallery-text"></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="u-backlink u-clearfix" style="background-color:#fffb00">
      <p class="u-text">
        <span style="font-size: 14px;">Copyright 2022</span>
      </p>
    </section>
  
<style>.u-disable-duration * {transition-duration: 0s !important;}</style><script>mendeleyWebImporter = {
  downloadPdfs(e,t) { return this._call('downloadPdfs', [e,t]); },
  open() { return this._call('open', []); },
  setLoginToken(e) { return this._call('setLoginToken', [e]); },
  _call(methodName, methodArgs) {
    const id = Math.random();
    window.postMessage({ id, token: '0.08873609553305739', methodName, methodArgs }, 'https://site167442.nicepage.io');
    return new Promise(resolve => {
      const listener = window.addEventListener('message', event => {
        const data = event.data;
        if (typeof data !== 'object' || !('result' in data) || data.id !== id) return;
        window.removeEventListener('message', listener);
        resolve(data.result);
      });
    });
  }
};</script></body></html>