<!DOCTYPE html>
<!-- saved from url=(0117)https://site167442.nicepage.io/?version=b01c0e46-5f3f-4c34-b22a-cc6105c5ad4a&uid=0cb57cf9-13d9-440a-a3ea-59fa48ebe52a -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl">
  <!-- HEAD -->
  <?php
    include "head.php";
  ?>
  <!-- END HEAD -->
  <body
    data-home-page="Page-2.html" data-home-page-title="Page 2" class="u-body u-xl-mode" data-lang="en">
    <!-- HEADER -->
    <?php
      include "header.php";
    ?>
    <!-- END HEADER -->

      <?php
        session_start();
        include "../config/koneksi.php";

        $message = "";
        if(isset($_POST['submit'])){
          $email = $_POST["email"];
          $checkemail = mysqli_query($conn, "SELECT email FROM tb_users WHERE email='$email'");
          if(mysqli_num_rows($checkemail) == 0){
            //$message = "Email ada";
            $message = "Incorrect Email or Not Registered";
          } else {
            $_SESSION['email'] = $checkemail;
            $result = mysqli_query($conn, "SELECT * FROM tb_users WHERE email='$email'");
            $row = mysqli_fetch_array($result);
            $userid = $row['userid'];
            
            //echo "$userid";
            //$_SESSION['userid'] = "001";
            //$_SESSION['namebib'] = $namebib
            ?>
            <script type="text/javascript">
            window.location = "printbib.php?email=<?php echo $email; ?>";
            </script>
            <?php
          }
        } 
      ?>

      <section class="u-align-left u-black u-clearfix u-section-5" id="carousel_ccf3">
        <div class="u-clearfix u-sheet u-valign-middle u-sheet-2">
          <div class="u-align-left u-container-style u-group u-group-1" style="margin-bottom:-100px">
            <div class="u-container-layout u-valign-middle u-container-layout-1">
              <h2 class="u-text u-text-1">DOWNLOAD BIB</h2>
            </div>
          </div>
          <div class="u-form u-form-1">
            <form method="post" action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>"
              class="u-form-spacing-20"
              style="padding: 10px">
                <div class="u-form-email u-form-group u-form-partition-factor-2 u-form-group-4">
                  <input type="email" placeholder="Enter a valid email address" id="email-f2a8" name="email" class="u-border-1 u-border-grey-30 u-grey-80 u-input u-input-rectangle" required="">
                </div>
                <?php echo $message; ?>
                <div class="u-align-left u-form-group u-form-submit">
                  <a class="u-border-2 u-border-white u-btn u-btn-rectangle u-btn-submit u-button-style u-none u-btn-1">Submit</a>
                  <input type="submit" name="submit" value="submit" class="u-form-control-hidden">
                </div>
            </form>
          </div>
        </div>
      </section>

      

    <section class="u-backlink u-clearfix" style="background-color:#fffb00">
      <p class="u-text">
        <span style="font-size: 14px;">Copyright 2022</span>
      </p>
    </section>
  
<style>.u-disable-duration * {transition-duration: 0s !important;}</style><script>mendeleyWebImporter = {
  downloadPdfs(e,t) { return this._call('downloadPdfs', [e,t]); },
  open() { return this._call('open', []); },
  setLoginToken(e) { return this._call('setLoginToken', [e]); },
  _call(methodName, methodArgs) {
    const id = Math.random();
    window.postMessage({ id, token: '0.08873609553305739', methodName, methodArgs }, 'https://site167442.nicepage.io');
    return new Promise(resolve => {
      const listener = window.addEventListener('message', event => {
        const data = event.data;
        if (typeof data !== 'object' || !('result' in data) || data.id !== id) return;
        window.removeEventListener('message', listener);
        resolve(data.result);
      });
    });
  }
};</script></body></html>