<!DOCTYPE html>
<!-- saved from url=(0117)https://site167442.nicepage.io/?version=b01c0e46-5f3f-4c34-b22a-cc6105c5ad4a&uid=0cb57cf9-13d9-440a-a3ea-59fa48ebe52a -->
<html style="font-size: 16px;" lang="en" class="u-responsive-xl">
  <!-- HEAD -->
  <?php
    include "head.php";
  ?>
  <!-- END HEAD -->
  <body
    data-home-page="Page-2.html" data-home-page-title="Page 2" class="u-body u-xl-mode" data-lang="en">
    <!-- HEADER -->
    <?php
      include "header.php";
    ?>
    <!-- END HEADER -->

    <!-- COUNTDOWN -->
    <?php
      include "countdown.php";
    ?>
    <!-- END COUNTDOWN -->

    <!-- BANNER 1 -->
    <section>
      <img src="../templates/kepri10k/banner1.png" style="width:100%; height:auto; object-fit: cover; margin-right:0;">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1"></div>
    </section>
    <!-- BANNER 2 -->
    <section style="margin-top:-10px">
      <img src="../templates/kepri10k/banner2.png" style="width:100%; height:auto; object-fit: cover; margin-top:0">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1"></div>
    </section>

    <!-- BANNER 3 -->
    <section style="margin-top:-10px">
      <img src="../templates/kepri10k/banner3.png" style="width:100%; height:auto; object-fit: cover; margin-top:0">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1"></div>
    </section>

    <!--
    <section class="u-clearfix u-section-2" id="carousel_adb9">
      <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
        <div class="u-layout">
          <div class="u-layout-row">
            <div class="u-align-center u-container-style u-layout-cell u-left-cell u-size-20 u-layout-cell-1">
              <div class="u-container-layout u-valign-middle u-container-layout-1">
                <img src="../templates/kepri10k/pexelsphoto1370750.jpeg" alt="" class="u-image u-image-default u-image-1" data-image-width="2250" data-image-height="1500">
              </div>
            </div>
            <div class="u-black u-container-style u-layout-cell u-size-29 u-layout-cell-2">
              <div class="u-container-layout u-valign-middle u-container-layout-2">
                <h6 class="u-text u-text-1">about us</h6>
                <h2 class="u-text u-text-2">This place is special...</h2>
                <p class="u-text u-text-3">Due to its commanding position, in the Second World War the Fort House was used by the military as an observation post and even had the roof reinforced to protect it from an aerial attack, with two feet of concrete, making
                                it bomb proof from enemy aircraft. With its historic harbour, rockpools and sandy beaches St Mawes provides the idyllic Cornish escape and The Fort House the perfect property in which to stay&nbsp;This spacious and airy
                                single storey holiday cottage sits in a private garden whose terrace provides uninterrupted views of the spectacular Cornish coastline.</p>
                <a href="https://nicepage.com/c/education-website-mockup" class="u-border-2 u-border-black u-link u-text-body-color u-link-1">read more</a>
              </div>
            </div>
            <div class="u-align-center-sm u-align-center-xs u-container-style u-layout-cell u-right-cell u-size-11 u-layout-cell-3">
              <div class="u-container-layout u-valign-middle-sm u-valign-middle-xs u-container-layout-3">
                <h2 class="u-text u-text-4">01</h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    -->

    <!--
    <section class="u-align-left u-clearfix u-image u-section-3" id="carousel_ca2a" data-image-width="2258" data-image-height="1500">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
        <h4 class="u-text u-text-body-alt-color u-text-default u-text-1">What People Say</h4><span class="u-icon u-icon-circle u-opacity u-opacity-45 u-text-palette-5-base u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 409.294 409.294" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-f23d"></use></svg><svg class="u-svg-content" viewBox="0 0 409.294 409.294" id="svg-f23d"><path d="m233.882 29.235v175.412h116.941c0 64.48-52.461 116.941-116.941 116.941v58.471c96.728 0 175.412-78.684 175.412-175.412v-175.412z"></path><path d="m0 204.647h116.941c0 64.48-52.461 116.941-116.941 116.941v58.471c96.728 0 175.412-78.684 175.412-175.412v-175.412h-175.412z"></path></svg></span>
        <h2 class="u-text u-text-body-alt-color u-text-2">Due to its commanding position, in the Second World War the Fort House was used by the military as an observation post and even had the roof reinforced to protect it from an aerial attack, with two feet of concrete, making it bomb proof from enemy aircraft.&nbsp;</h2>
        <h6 class="u-text u-text-body-alt-color u-text-default u-text-3">Nick Cave</h6>
        <a href="https://nicepage.cloud/" class="u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-none u-btn-1">Read More</a>
      </div>
    </section>
    -->

    <!--
    <section class="u-clearfix u-section-4" id="carousel_e864">
      <img src="../templates/kepri10k/Untitled-5.jpg" alt="" class="u-image u-image-default u-image-1">
      <div class="u-list u-list-1">
        <div class="u-repeater u-repeater-1">
          <div class="u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-container-layout-1">
              <h5 class="u-text u-text-1">Join the Movement</h5>
              <p class="u-text u-text-2">Sample text. Click to select the text box. Click again or double click to start editing the text.&nbsp;<a href="https://nicepage.com/" target="_blank">Duis aute irure dolor</a>. 
              </p>
            </div>
          </div>
          <div class="u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-container-layout-2">
              <h5 class="u-text u-text-3">Transform lives</h5>
              <p class="u-text u-text-4">Sample text. Click to select the text box. Click again or double click to start editing the text.&nbsp;Duis aute irure dolor. </p>
            </div>
          </div>
          <div class="u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-container-layout-3">
              <h5 class="u-text u-text-5">Train for a Race</h5>
              <p class="u-text u-text-6">Sample text. Click to select the text box. Click again or double click to start editing the text.<br>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
    -->

    <!-- FORM -->
    <section class="u-align-left u-black u-clearfix u-section-5" id="carousel_ccf3" style="margin-top:-10px">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-2" style="margin-top:-60px; margin-bottom:30px">
        <div class="u-align-left u-container-style u-group u-group-1">
          <div class="u-container-layout u-valign-middle u-container-layout-1">
            <h2 id="registrasilabelx" class="u-text u-text-1">REGISTRASI DITUTUP</h2>
            <h3 id="registrasidescriptionx" class="u-text u-text-2 fw-bold">Total 757 Peserta</h3>
          </div>
        </div> 
      </div>
    </section>
    <style class="u-overlap-style">.u-overlap:not(.u-sticky-scroll)
    .u-header {
      background-color: #f1c50e !important
    }
    </style>
    
    <!--
    <footer class="u-align-center u-black u-clearfix u-footer u-footer" id="sec-b6ca">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the Text Element.</p>
      </div>
    </footer>
    -->
    <section class="u-align-center u-black u-clearfix u-section-6" id="carousel_ccf3" style="margin-top:-10px; background-color:#FFF; width:100%">
      <div class="u-clearfix u-sheet u-valign-middle u-sheet-2" style="margin-top:-80px; margin-bottom:-50px">
        <div class="u-align-center u-container-style u-group u-group-1">
          <div class="u-container-layout u-valign-middle u-container-layout-1">
            <h2 class="u-text u-text-1" style="color:#000; text-align: center;">Sponsor</h2>
          </div>
        </div>
      </div>
    </section>
    <section id="sponsor" class="u-backlink u-clearfix">
      <iframe src="sponsor.html" width="100%" height="100%" frameBorder="0"></iframe>
    </section>

    <section class="u-backlink u-clearfix" style="background-color:#fffb00">
      <p class="u-text">
        <span style="font-size: 14px;">Copyright 2022</span>
      </p>
    </section>
  
<style>.u-disable-duration * {transition-duration: 0s !important;}</style>
<script>mendeleyWebImporter = {
  downloadPdfs(e,t) { return this._call('downloadPdfs', [e,t]); },
  open() { return this._call('open', []); },
  setLoginToken(e) { return this._call('setLoginToken', [e]); },
  _call(methodName, methodArgs) {
    const id = Math.random();
    window.postMessage({ id, token: '0.08873609553305739', methodName, methodArgs }, 'https://site167442.nicepage.io');
    return new Promise(resolve => {
      const listener = window.addEventListener('message', event => {
        const data = event.data;
        if (typeof data !== 'object' || !('result' in data) || data.id !== id) return;
        window.removeEventListener('message', listener);
        resolve(data.result);
      });
    });
  }
};
</script>
<script>
  /*function toggleLanguage(language) {
    let description = document.getElementsByClassName("description");
    if (language === "Bahasa") {
      description.innerHTML = "Show Bahasa Text";
      console.log("Bahasa");
    }
    else {
      description.innerHTML = "Show English Text";
      console.log("English");
    }
  }*/
</script>
</body>
</html>