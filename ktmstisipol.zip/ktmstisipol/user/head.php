  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <script type="text/javascript">
      (function() {
        var container = document.querySelector('#_tcx-batuega1s9f');
        if (!container) {
          return;
        }

        function addToContainer(url, text) {
          const wrapper = document.createElement('div');
          wrapper.setAttribute('data-tcx-url', url);
          wrapper.innerText = text;
          container.appendChild(wrapper);
        }

        const fetch = window.fetch
        window.fetch = function() {
          return Promise.resolve(fetch.apply(window, arguments))
              .then(async response => {
                if (response.ok) {
                  try {
                    const clone = response.clone();
                    const json = await clone.json();
                    addToContainer(clone.url, JSON.stringify(json));
                  } catch (err) {}
                }
                return response;
              });
        };

        var XHR = XMLHttpRequest.prototype;
        var send = XHR.send;
        var open = XHR.open;
        XHR.open = function(method, url) {
          this.url = url;
          return open.apply(this, arguments);
        };
        XHR.send = function() {
          this.addEventListener('load', function() {
            try {
              const response = this.response;
              if (response && response.length) {
                const firstChar = response[0];
                if (firstChar === '[' || firstChar === '{') {
                  addToContainer(this.url, response);
                }
              }
            } catch (err) {
              // No-op.
            }
          });
          return send.apply(this, arguments);
        };
      })();
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="live. move. refuel., Best Gym Membership, This place is special..., 01, Due to its commanding position, in the Second World War the Fort House was used by the military as an observation post and even had the roof reinforced to protect it from an aerial attack, with two feet of concrete, making it bomb proof from enemy aircraft., Make a reservation">
    <meta name="description" content="">
    <title>Kepri Running Tour</title>
    <link rel="stylesheet" href="../templates/kepri10k/nicepage.css" media="screen">
    <link rel="stylesheet" href="../templates/kepri10k/nicepage-site.css" media="screen">
    <link rel="stylesheet" href="../templates/kepri10k/Page-2.css" media="screen">
    <script class="u-script" type="text/javascript" src="../templates/kepri10k/jquery-3.5.1.min.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="../templates/kepri10k/nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.19.3, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="../templates/kepri10k/css">

    <script type="application/ld+json">
      {
        "@context": "http://schema.org",
        "@type": "Organization",
        "name": "",
        "logo": "https://assets.nicepagecdn.com/8de90dd0/3088476/images/logo.png"
      }
    </script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Page 2">
    <meta property="og:type" content="website">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800&display=swap" rel="stylesheet">
  </head>