<?php
session_start();
include "../templates/architectui/style.php";
include "functions.php";
include "not_login.php";
include "../config/koneksi.php";
?>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <!-- HEADER -->
            <?php include "../templates/architectui/header.php"; ?>
        <!-- END HEADER -->
        <div class="ui-theme-settings">
            <button type="button" id="TooltipDemo" class="btn-open-options btn btn-warning">
                <i class="fa fa-cog fa-w-16 fa-spin fa-2x"></i>
            </button>
        </div>
            <div class="app-main">
                <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>
                    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <!-- MENU -->
                                <?php include "../templates/architectui/menu.php"; ?>
                            <!-- END MENU -->
                        </div>
                    </div>
                </div>
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <!-- KONTEN -->

                                <div class="col-lg-12">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Peserta Aktif</h5>
                                        <table class="mb-0 table table-borderless">
                                            <thead>
                                            <tr>
                                                <th>No</th>
                                                <!--<th>Username</th>-->
                                                <th>Nama</th>
                                                <th>Email</th>
                                                <th>Nomor HP</th>
                                                <th colspan="2">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $ambil_data = mysqli_query($conn, "SELECT * FROM tb_users ");
                                                $posisi = 0;
                                                $no = $posisi+1;
                                                while($hasil_data = mysqli_fetch_array($ambil_data)){
                                            ?>
                                            <tr>
                                                <th scope="row"><?php echo $no; ?></th>
                                                <td><?php echo $hasil_data['nama']; ?></td>
                                                <td><?php echo $hasil_data['email']; ?></td>
                                                <td><?php echo $hasil_data['phone']; ?></td>
                                                <td><a href="detail.php?detail&email=<?php echo $hasil_data['email'];?>"><button class="mb-2 mr-2 btn btn-warning">Detail</button></a></td>
                                                <td><a href="edit.php?edit&email=<?php echo $hasil_data['email'];?>"><button class="mb-2 mr-2 btn btn-primary">Edit</button></a></td>
                                                
                                            </tr>
                                            <?php
                                                $no++;
                                                }
                                            ?>
                                            
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        <!-- END KONTEN -->
                    </div>

                    <div class="app-wrapper-footer">
                    <?php include "../templates/architectui/footer.php"; ?>    
                    </div>
                </div>
                <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        </div>
    </div>
</body>