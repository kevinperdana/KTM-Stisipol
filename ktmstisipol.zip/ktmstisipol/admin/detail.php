<?php
session_start();
include "../templates/architectui/style.php";
include "functions.php";
include "not_login.php";
include "../config/koneksi.php";

if(isset($_GET['detail'])){
$sql = "SELECT * FROM tb_users WHERE email='{$_GET['email']}'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_object($query);
$nama = $row->nama;
$email = $row->email;
$gender = $row->gender;
$placeofbirth = $row->placeofbirth;
$birthdate = $row->birthdate;
$phone = $row->phone;
$alamat = $row->alamat;
$city = $row->city;
$province = $row->province;
$nationality = $row->nationality;
$bloodtype = $row->bloodtype;
$idnumbertype = $row->idnumbertype;
$idnumber = $row->idnumber;
$category = $row->category;
$nameemergency = $row->nameemergency;
$phoneemergency = $row->phoneemergency;
$riwayatjantung = $row->riwayatjantung;
$riwayathipertensi = $row->riwayathipertensi;
$riwayatkronik = $row->riwayatkronik;
$riwayatepilepsi = $row->riwayatepilepsi;
$riwayatasma = $row->riwayatasma;
$riwayatasuransi = $row->riwayatasuransi;
$riwayatalergi = $row->riwayatalergi;
$alergi = $row->alergi;
$namebib = $row->namebib;
$ukuranbaju = $row->ukuranbaju;
$nourut = $row->nourut;
$urlpayment = $row->urlpayment;
//echo $nama;
}
?>

<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
        <!-- HEADER -->
            <?php include "../templates/architectui/header.php"; ?>
        <!-- END HEADER -->
        <div class="ui-theme-settings">
            <button type="button" id="TooltipDemo" class="btn-open-options btn btn-warning">
                <i class="fa fa-cog fa-w-16 fa-spin fa-2x"></i>
            </button>
        </div>
            <div class="app-main">
                <div class="app-sidebar sidebar-shadow">
                    <div class="app-header__logo">
                        <div class="logo-src"></div>
                        <div class="header__pane ml-auto">
                            <div>
                                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                    <span class="hamburger-box">
                                        <span class="hamburger-inner"></span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="app-header__mobile-menu">
                        <div>
                            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="app-header__menu">
                        <span>
                            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                                <span class="btn-icon-wrapper">
                                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                                </span>
                            </button>
                        </span>
                    </div>
                    <div class="scrollbar-sidebar">
                        <div class="app-sidebar__inner">
                            <!-- MENU -->
                                <?php include "../templates/architectui/menu.php"; ?>
                            <!-- END MENU -->
                        </div>
                    </div>
                </div>
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <!-- KONTEN -->

                        <div class="col-lg-12">
                          <div class="main-card mb-3 card">
                            <div class="card-body">
                              <h5 class="card-title">Detail Peserta</h5>
                                <div class="form-row">
                                  <div class="col-md-8">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Nama</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $nama ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-2">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">No Urut</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $nourut ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-2">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Kategori</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $category ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="position-relative form-group">
                                  <label for="exampleAddress" class="">Email</label>
                                  <input id="exampleAddress" class="form-control" value="<?php echo $email ?>">
                                </div>
                                <div class="form-row">
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Gender</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $gender ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Tempat Lahir</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $placeofbirth ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Tanggal Lahir</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $birthdate ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="position-relative form-group">
                                  <label for="exampleAddress2" class="">Nomor Handphone</label>
                                  <input id="exampleAddress2" class="form-control" value="<?php echo $phone ?>">
                                </div>
                                <div class="position-relative form-group">
                                  <label for="exampleAddress2" class="">Alamat</label>
                                  <input id="exampleAddress2" class="form-control" value="<?php echo $alamat ?>">
                                </div>
                                <div class="form-row">
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Kota</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $city ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Provinsi</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $province ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Warga Negara</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $nationality ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Golongan Darah</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $bloodtype ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Jenis ID</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $idnumbertype ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Nomor ID</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $idnumber ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Nama Kontak Darurat</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $nameemergency ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Nomor Telepon Kontak Darurat</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $phoneemergency ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Memiliki Riwayat Penyakit Jantung</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts" class="form-check-input" value="success" <?php echo ($riwayatjantung == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts" class="form-check-input" value="info" <?php echo ($riwayatjantung == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Memiliki Riwayat Penyakit Hipertensi</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts2" class="form-check-input" value="success" <?php echo ($riwayathipertensi == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts2" class="form-check-input" value="info" <?php echo ($riwayathipertensi == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Memiliki Riwayat Penyakit Kronik/Tahunan Lainnya (Diabetes Melitus, Ginjal, Hepatitis, dll)</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts3" class="form-check-input" value="success" <?php echo ($riwayatkronik == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts3" class="form-check-input" value="info" <?php echo ($riwayatkronik == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Memiliki Riwayat Penyakit Epilepsi dan/atau Gangguan Saraf Lainnya</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts4" class="form-check-input" value="success" <?php echo ($riwayatepilepsi == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts4" class="form-check-input" value="info" <?php echo ($riwayatepilepsi == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Memiliki Riwayat Penyakit Asma/Saluran Pernafasan Lainnya</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts5" class="form-check-input" value="success" <?php echo ($riwayatasma == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts5" class="form-check-input" value="info" <?php echo ($riwayatasma == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Memiliki Asuransi BPJS dan/atau Asuransi Lainnya</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts6" class="form-check-input" value="success" <?php echo ($riwayatasuransi == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts6" class="form-check-input" value="info" <?php echo ($riwayatasuransi == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Memiliki Riwayat Alergi Terhadap Obat Tertentu</label>
                                      <div id="toastTypeGroup">
                                        <div class="form-check">
                                          <input type="radio" name="toasts7" class="form-check-input" value="success" <?php echo ($riwayatalergi == 'Ya') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Ya</label>
                                        </div>
                                        <div class="form-check">
                                          <input type="radio" name="toasts7" class="form-check-input" value="info" <?php echo ($riwayatalergi == 'Tidak') ?  "checked" : "" ;  ?>>
                                          <label class="form-check-label" for="exampleRadios1">Tidak</label>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Jika Iya Sebutkan</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $alergi ?>">
                                    </div>
                                  </div>
                                </div>
                                <div class="form-row">
                                  <div class="col-md-4">
                                    <div class="position-relative form-group">
                                      <label for="exampleEmail11" class="">Nama pada BIB</label>
                                      <input id="exampleEmail11" class="form-control" value="<?php echo $namebib ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-2">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Ukuran Baju</label>
                                      <input id="examplePassword11" class="form-control" value="<?php echo $ukuranbaju ?>">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="position-relative form-group">
                                      <label for="examplePassword11" class="">Struk/Nota Konfirmasi Pembayaran</label>
                                      <br>
                                      <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal">Lihat Struk</button>
                                    </div>
                                  </div>
                                </div>
                            </div>
                                    
                          </div>
                        </div>

                        <!-- END KONTEN -->
                    </div>

                    <div class="app-wrapper-footer">
                    <?php include "../templates/architectui/footer.php"; ?>    
                    </div>
                </div>
                <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
        </div>
    </div>
</body>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Struk</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
          <!--<p class="mb-0">Xx</p>-->
          <img src="http://localhost/kepri10k/user/upload/<?php echo $urlpayment ?>" alt="" width="100%">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>