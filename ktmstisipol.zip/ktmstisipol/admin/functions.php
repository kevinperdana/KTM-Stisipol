<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
include "../config/koneksi.php";

/*function loggedin(){
	if(isset($_SESSION["id_admin"]) && empty($_SESSION["password"])){
		return true;
		} else{
			return false;
			}
	}
if(loggedin()){
	$my_id = $_SESSION["id_admin"];
	$user_query = mysqli_query($conn, "SELECT username FROM tb_admin WHERE id_admin='$my_id'");
	$run_user = mysqli_fetch_array($user_query);
	$username = $run_user["username"];
	}*/
?>