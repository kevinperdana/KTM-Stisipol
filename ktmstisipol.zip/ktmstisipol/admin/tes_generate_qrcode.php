<!DOCTYPE html>
<html lang="en">
<head>
  <title>QR Code</title>
</head>
<body>
  <form action="proses_generate_qrcode.php" method="POST">
    <input type="text" name="qr">
    <input type="submit" name="submit" value="GENERATE QR CODE">
  </form>
</body>
</html>