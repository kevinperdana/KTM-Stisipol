<?php 
$url = 'http://backend.stisipolrajahaji.ac.id/v2/auth/login';
$data = ['username' => 'ktm', 'password' => '!Ktm2023', 'page' => 'm'];

// use key 'http' even if you send the request to https://...
$options = [
    'http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data),
        'Accept' => "application/json",
    ],
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
if ($result === false) {
    /* Handle error */
}

var_dump($result);
?>