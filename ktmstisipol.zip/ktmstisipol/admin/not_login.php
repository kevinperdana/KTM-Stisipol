<?php
	if(empty($_SESSION["id_admin"]) && empty($_SESSION["password"])){
        //header('Refresh:0; ../pemasaran/index.php');
        header("location: login.php");
        } else{
            //return false;
            }
?>