<!DOCTYPE html>
<html lang="en">
<head>
    <title>ePaper Tanjungpinang Pos</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
    <link rel="icon" type="image/png" href="../templates/logincolorlib/images/icons/favicon.ico"/>
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/animate/animate.css">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/select2/select2.min.css">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/css/util.css">
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/css/main.css">
<!--===============================================================================================-->
</head>
<body>
<?php
include "../config/koneksi.php";
include "functions.php";

if(isset($_POST["submit"])){
	$username = $_POST["username"];
	$password = $_POST["password"];
	if(empty($username) or empty($password)){
		header("location: login.php");
	} else{
		$check_login = mysqli_query($conn,"SELECT id_admin FROM tb_admin WHERE username='$username' AND password='$password'");
		if(mysqli_num_rows($check_login) == 1){
			$run = mysqli_fetch_array($check_login);
			$id_admin = $run["id_admin"];
      $_SESSION["id_admin"] = $id_admin;
      header("location: index.php");
			} else{
				?>
                        <div class="limiter">
					        <div class="container-login100">
					            <div class="wrap-login100">
					                <form class="login100-form validate-form"  method="post" action="cek_login.php">
					                    
					                    <span class="login100-form-title p-b-48">
					                        <i class="zmdi zmdi-block-alt"></i>
					                    </span>

					                    <span class="login100-form-title p-b-48">
					                        USERNAME ATAU
					                        PASSWORD SALAH
					                    </span>

					                    <div class="container-login100-form-btn">
					                        <div class="wrap-login100-form-btn">
					                            <div class="login100-form-bgbtn"></div>
					                            <a href="login.php"><input type="submit" name="submit" class="btn btn-lg btn-warning btn-block" value="Coba Lagi"></a>
					                        </div>
					                    </div>
					                    <!--
					                    <div class="text-center p-t-115">
					                        <span class="txt1">
					                            Don’t have an account?
					                        </span>

					                        <a class="txt2" href="#">
					                            Sign Up
					                        </a>
					                    </div>
					                    -->
					                </form>
					            </div>
					        </div>
					    </div>
                <?php
				}
		}
}
?>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/bootstrap/js/popper.js"></script>
    <script src="../templates/logincolorlib/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/daterangepicker/moment.min.js"></script>
    <script src="../templates/logincolorlib/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/js/main.js"></script>

</body>
</html>