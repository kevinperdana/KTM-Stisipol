<?php

$postRequest = array(
    'username' => 'ktm',
    'password' => '!Ktm2023',
    'page' => 'm',
);

curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, array(
  'Accept' => 'application/json',
));

$cURLConnection = curl_init('http://backend.stisipolrajahaji.ac.id/v2/auth/login');
curl_setopt($cURLConnection, CURLOPT_POSTFIELDS, $postRequest);
curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);

$apiResponse = curl_exec($cURLConnection);
var_dump($apiResponse);
curl_close($cURLConnection);

// $apiResponse - available data from the API request
//$jsonArrayResponse - json_decode($apiResponse);

// Further processing ...
if ($server_output == "OK") {

} else {
  
}
?>