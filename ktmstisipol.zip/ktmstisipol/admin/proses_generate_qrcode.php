<?php
include "../plugins/phpqrcode/qrlib.php"; 

//$isi = "23101085"; 
if($_SERVER["REQUEST_METHOD"]=="POST"){
  $isi = $_POST["qr"];
  QRcode::png($isi, false, L, '18', '2');
}
?>
