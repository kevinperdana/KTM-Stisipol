<?php include '../config/koneksi.php'; ?>
<?php include 'functions.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Kepri Running Tour</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
    <link rel="icon" type="image/png" href="../templates/logincolorlib/images/icons/favicon.ico"/>
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/animate/animate.css">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/select2/select2.min.css">
<!--===============================================================================================-->  
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/css/util.css">
    <link rel="stylesheet" type="text/css" href="../templates/logincolorlib/css/main.css">
<!--===============================================================================================-->
</head>
<body>
    <?php
    if(!empty($_SESSION["id_admin"]) && empty($_SESSION["password"])){
        //header('Refresh:0; ../pemasaran/index.php');
        header("location: index.php");
        } else{
            //return false;
            }
    ?>
    
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form"  method="post" action="cek_login.php">
                    <!--<span class="login100-form-title p-b-26">
                        ePaper Management
                    </span>
                    
                    <span class="login100-form-title p-b-48">
                        <i class="zmdi zmdi-font"></i>
                    </span> -->
                    <div class="text-center">
                        <span class="txt2">
                            Admin Management
                        </span>
                    </div>
                    <span class="login100-form-title p-b-48" style="color: #2e426b">
                        Kepri Running Tour
                    </span>

                    <div class="wrap-input100 validate-input" data-validate = "">
                        <input class="input100" type="text" name="username">
                        <span class="focus-input100" data-placeholder="Username"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter password">
                        <span class="btn-show-pass">
                            <i class="zmdi zmdi-eye"></i>
                        </span>
                        <input class="input100" type="password" name="password">
                        <span class="focus-input100" data-placeholder="Password"></span>
                    </div>

                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <input type="submit" name="submit" class="btn btn-lg btn-primary btn-block" value="Login">
                        </div>
                    </div>
                    <!--
                    <div class="text-center p-t-115">
                        <span class="txt1">
                            Don’t have an account?
                        </span>

                        <a class="txt2" href="#">
                            Sign Up
                        </a>
                    </div>
                    -->
                </form>
            </div>
        </div>
    </div>
    

    <div id="dropDownSelect1"></div>
    
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/bootstrap/js/popper.js"></script>
    <script src="../templates/logincolorlib/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/daterangepicker/moment.min.js"></script>
    <script src="../templates/logincolorlib/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
    <script src="../templates/logincolorlib/js/main.js"></script>

</body>
</html>