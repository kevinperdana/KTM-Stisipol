<?php
	header("location: admin/login.php");
	//header("location: index.html");
?>