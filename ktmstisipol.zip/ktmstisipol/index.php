<?php
	header("location: user/index.php");
	//header("location: index.html");
?>