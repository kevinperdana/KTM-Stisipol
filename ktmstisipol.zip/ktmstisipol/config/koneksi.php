<?php
$server   = "127.0.0.1";
$username = "root";
$password = "12345678";
$database = "kepri10k";

$koneksi = mysqli_connect($server,$username,$password) or die ('Koneksi gagal');
$conn = new mysqli($server, $username, $password, $database);

if($koneksi){
 mysqli_select_db($conn, $database) or die ('Database belum dibuat'); 
}
?>
