<ul class="vertical-nav-menu">
<li class="app-sidebar__heading">Peserta</li>
        <li>
            <a href="index.php">
                <i class="metismenu-icon pe-7s-user"></i>
                Daftar Peserta
            </a>
        </li>
</ul>