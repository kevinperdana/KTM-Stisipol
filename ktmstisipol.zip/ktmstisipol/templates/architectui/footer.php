                        <div class="app-footer">
                            <div class="app-footer__inner">
                                <div class="app-footer-left">
                                    <ul class="nav">
                                        <li class="nav-item">
                                            <a class="nav-link">
                                                Copyright 2022 | Kepri Running Tour
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                 
                                <div class="app-footer-right">
                                    <ul class="nav">
                                        <li class="nav-item">
                                            <a class="nav-link">
                                                Version 1.0.0
                                            </a>
                                        </li>
                                        <!--<li class="nav-item">
                                            <a href="javascript:void(0);" class="nav-link">
                                                <div class="badge badge-success mr-1 ml-0">
                                                    <small>NEW</small>
                                                </div>
                                                Footer Link 4
                                            </a>
                                        </li> -->
                                    </ul>
                                </div>
                            	
                            </div>
                        </div>