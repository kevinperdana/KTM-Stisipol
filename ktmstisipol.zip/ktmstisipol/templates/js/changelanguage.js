let langs = document.querySelector(".dropdown-language"),
     link = document.querySelectorAll("a");
     //titleform = document.querySelector("#titleform"),
     //descr = document.querySelector(".description");

link.forEach(el=>{
     el.addEventListener("click", ()=>{
          langs.querySelector(".active");
          el.classList.add("active");

          let attr = el.getAttribute("language")

          console.log(attr)

          //titleform.textContent = data[attr].titleform
          //descr.textContent = data[attr].description
          console.log(data[attr].registrasilabel)
          document.getElementById("registrasilabel").innerHTML = data[attr].registrasilabel;
          document.getElementById("registrasidescription").innerHTML = data[attr].registrasidescription;
          document.getElementById("namelabel").innerHTML = data[attr].namelabel;
          document.getElementById("nameinput").placeholder = data[attr].nameinput;
          document.getElementById("emailinput").placeholder = data[attr].emailinput;
          document.getElementById("genderlabel").innerHTML = data[attr].genderlabel;
          document.getElementById("genderoption1").innerHTML = data[attr].genderoption1;
          document.getElementById("genderoption2").innerHTML = data[attr].genderoption2;
          document.getElementById("placeofbirthlabel").innerHTML = data[attr].placeofbirthlabel;
          document.getElementById("placeofbirthinput").placeholder = data[attr].placeofbirthinput;
          document.getElementById("birthdatelabel").innerHTML = data[attr].birthdatelabel;
          document.getElementById("phonelabel").innerHTML = data[attr].phonelabel;
          document.getElementById("phoneinput").placeholder = data[attr].phoneinput;
          document.getElementById("addresslabel").innerHTML = data[attr].addresslabel;
          document.getElementById("addressinput").placeholder = data[attr].addressinput;
          document.getElementById("citylabel").innerHTML = data[attr].citylabel;
          document.getElementById("cityinput").placeholder = data[attr].cityinput;
          document.getElementById("provincelabel").innerHTML = data[attr].provincelabel;
          document.getElementById("provinceinput").placeholder = data[attr].provinceinput;
          document.getElementById("nationalitylabel").innerHTML = data[attr].nationalitylabel;
          document.getElementById("nationalityoption1").innerHTML = data[attr].nationalityoption1;
          document.getElementById("bloodtypelabel").innerHTML = data[attr].bloodtypelabel;
          document.getElementById("bloodtypeoption1").innerHTML = data[attr].bloodtypeoption1;
          document.getElementById("idnumbertypelabel").innerHTML = data[attr].idnumbertypelabel;
          document.getElementById("idnumberlabel").innerHTML = data[attr].idnumberlabel;
          document.getElementById("idnumberinput").placeholder = data[attr].idnumberinput;
          document.getElementById("categorylabel").innerHTML = data[attr].categorylabel;
          document.getElementById("categoryoption1").innerHTML = data[attr].categoryoption1;
          document.getElementById("categoryoption2").innerHTML = data[attr].categoryoption2;
          document.getElementById("categoryoption3").innerHTML = data[attr].categoryoption3;
          document.getElementById("nameemergencylabel").innerHTML = data[attr].nameemergencylabel;
          document.getElementById("nameemergencyinput").placeholder = data[attr].nameemergencyinput;
          document.getElementById("phoneemergencylabel").innerHTML = data[attr].phoneemergencylabel;
          document.getElementById("phoneemergencyinput").placeholder = data[attr].phoneemergencyinput;
          document.getElementById("jantunglabel").innerHTML = data[attr].jantunglabel;
          document.getElementById("jantunglabelyes").innerHTML = data[attr].jantunglabelyes;
          document.getElementById("jantunglabelno").innerHTML = data[attr].jantunglabelno;
          document.getElementById("hipertensilabel").innerHTML = data[attr].hipertensilabel;
          document.getElementById("hipertensilabelyes").innerHTML = data[attr].hipertensilabelyes;
          document.getElementById("hipertensilabelno").innerHTML = data[attr].hipertensilabelno;
          document.getElementById("kroniklabel").innerHTML = data[attr].kroniklabel;
          document.getElementById("kroniklabelyes").innerHTML = data[attr].kroniklabelyes;
          document.getElementById("kroniklabelno").innerHTML = data[attr].kroniklabelno;
          document.getElementById("epilepsilabel").innerHTML = data[attr].epilepsilabel;
          document.getElementById("epilepsilabelyes").innerHTML = data[attr].epilepsilabelyes;
          document.getElementById("epilepsilabelno").innerHTML = data[attr].epilepsilabelno;
          document.getElementById("asmalabel").innerHTML = data[attr].asmalabel;
          document.getElementById("asmalabelyes").innerHTML = data[attr].asmalabelyes;
          document.getElementById("asmalabelno").innerHTML = data[attr].asmalabelno;
          document.getElementById("asuransilabel").innerHTML = data[attr].asuransilabel;
          document.getElementById("asuransilabelyes").innerHTML = data[attr].asuransilabelyes;
          document.getElementById("asuransilabelno").innerHTML = data[attr].asuransilabelno;
          document.getElementById("alergilabel").innerHTML = data[attr].alergilabel;
          document.getElementById("alergilabelyes").innerHTML = data[attr].alergilabelyes;
          document.getElementById("alergilabelno").innerHTML = data[attr].alergilabelno;
          document.getElementById("alergideskripsilabel").innerHTML = data[attr].alergideskripsilabel;
          document.getElementById("alergideskripsiinput").placeholder = data[attr].alergideskripsiinput;
          document.getElementById("namebiblabel").innerHTML = data[attr].namebiblabel;
          document.getElementById("namebibinput").placeholder = data[attr].namebibinput;
          document.getElementById("ukuranbajulabel").innerHTML = data[attr].ukuranbajulabel;
          document.getElementById("paymentreceiptlabel").innerHTML = data[attr].paymentreceiptlabel;
     })
})

//sessionStorage.setItem("registrasi", "Tes")

let data = {
     bahasa: {
          registrasilabel: "Registrasi",
          registrasidescription: "Silahkan isi formulir, jika Anda siap untuk mengikuti Tanjungpinang Running Tour 2022.",
          namelabel: "Nama",
          nameinput: "Masukkan email Anda",
          emailinput: "Masukkan nama Anda",
          genderlabel: "Jenis Kelamin",
          genderoption1: "Laki-Laki",
          genderoption2: "Perempuan",
          placeofbirthlabel: "Tempat Lahir",
          placeofbirthinput: "Masukkan Tempat Lahir Anda",
          birthdatelabel: "Tanggal Lahir",
          phonelabel: "Nomor Handphone",
          phoneinput: "Masukkan nomor handphone (contoh: 081290901919)",
          addresslabel: "Alamat",
          addressinput: "Masukkan alamat Anda",
          citylabel: "Kota",
          cityinput: "Masukkan kota Anda",
          provincelabel: "Provinsi",
          provinceinput: "Masukkan provinsi Anda",
          nationalitylabel: "Warga Negara",
          nationalityoption1: "Lainnya",
          bloodtypelabel: "Golongan Darah",
          bloodtypeoption1: "Tidak Diketahui",
          idnumbertypelabel: "Jenis ID",
          idnumberlabel: "Nomor ID",
          idnumberinput: "Masukkan nomor ID Anda",
          categorylabel: "Kategori",
          categoryoption1: "Umum (19 - 44 tahun)",
          categoryoption2: "Pelajar (15 - 18 tahun)",
          categoryoption3: "Veteran (45 - 75 tahun)",
          nameemergencylabel: "Nama Kontak Darurat",
          nameemergencyinput: "Masukkan nama kontak darurat",
          phoneemergencylabel: "Nomor Telepon Kontak Darurat",
          phoneemergencyinput: "Masukkan nomor telepon kontak darurat",
          jantunglabel: "Memiliki Riwayat Penyakit Jantung",
          jantunglabelyes: "Ya",
          jantunglabelno: "Tidak",
          hipertensilabel: "Memiliki Riwayat Penyakit Hipertensi",
          hipertensilabelyes: "Ya",
          hipertensilabelno: "Tidak",
          kroniklabel: "Memiliki Riwayat Penyakit Kronik/Tahunan Lainnya (Diabetes Melitus, Ginjal, Hepatitis, dll)",
          kroniklabelyes: "Ya",
          kroniklabelno: "Tidak",
          epilepsilabel: "Memiliki Riwayat Penyakit Epilepsi dan/atau Gangguan Saraf Lainnya",
          epilepsilabelyes: "Ya",
          epilepsilabelno: "Tidak",
          asmalabel: "Memiliki Riwayat Penyakit Asma/Saluran Pernafasan Lainnya",
          asmalabelyes: "Ya",
          asmalabelno: "Tidak",
          asuransilabel: "Memiliki Asuransi BPJS dan/atau Asuransi Lainnya",
          asuransilabelyes: "Ya",
          asuransilabelno: "Tidak",
          alergilabel: "Memiliki Riwayat Alergi Terhadap Obat Tertentu",
          alergilabelyes: "Ya",
          alergilabelno: "Tidak",
          alergideskripsilabel: "Jika Iya Sebutkan",
          alergideskripsiinput: "Sebutkan alergi",
          namebiblabel: "Nama pada BIB",
          namebibinput: "Masukkan nama yang valid pada BIB",
          ukuranbajulabel: "Ukuran Baju",
          paymentreceiptlabel: "Struk/Nota Konfirmasi Pembayaran",
     },
     english: {
          registrasilabel: "Register",
          registrasidescription: "Please submit this form when you are ready to secure your place in the Tanjungpinang Running Tour 2022.",
          namelabel: "Name",
          nameinput: "Enter your Name",
          emailinput: "Enter a valid email address",
          genderlabel: "Gender",
          genderoption1: "Male",
          genderoption2: "Female",
          placeofbirthlabel: "Place of Birth",
          placeofbirthinput: "Enter your place of birth",
          birthdatelabel: "Birth Date",
          phonelabel: "Phone",
          phoneinput: "Enter your phone (e.g. 081290901919)",
          addresslabel: "Address",
          addressinput: "Enter a valid address",
          citylabel: "City",
          cityinput: "Enter a valid city",
          provincelabel: "Province",
          provinceinput: "Enter a valid province",
          nationalitylabel: "Nationality",
          nationalityoption1: "Other",
          bloodtypelabel: "Blood Type",
          bloodtypeoption1: "Unknown",
          idnumbertypelabel: "ID Number Type",
          idnumberlabel: "ID Number",
          idnumberinput: "Enter a valid ID number",
          categorylabel: "Category",
          categoryoption1: "General (19 - 44 years old)",
          categoryoption2: "Student (15 - 18 years old)",
          categoryoption3: "Veterans (45 - 75 years old)",
          nameemergencylabel: "Name of Emergency Contact",
          nameemergencyinput: "Enter a valid name of emergency contact",
          phoneemergencylabel: "Phone Number of Emergency Contact",
          phoneemergencyinput: "Enter a valid phone number of emergency contact",
          jantunglabel: "History of Heart Disease",
          jantunglabelyes: "Yes",
          jantunglabelno: "No",
          hipertensilabel: "History of Hypertension",
          hipertensilabelyes: "Yes",
          hipertensilabelno: "No",
          kroniklabel: "History of Other Chronic/Annual Diseases (Diabetes Mellitus, Kidney, Hepatitis, etc.)",
          kroniklabelyes: "Yes",
          kroniklabelno: "No",
          epilepsilabel: "History of Epilepsy and/or Other Nervous Disorders",
          epilepsilabelyes: "Yes",
          epilepsilabelno: "No",
          asmalabel: "History of Asthma/Other Respiratory Diseases",
          asmalabelyes: "Yes",
          asmalabelno: "No",
          asuransilabel: "Have BPJS Insurance and/or Other Insurance",
          asuransilabelyes: "Yes",
          asuransilabelno: "No",
          alergilabel: "History of Allergies to Certain Drugs",
          alergilabelyes: "Yes",
          alergilabelno: "No",
          alergideskripsilabel: "If Yes, Mention It",
          alergideskripsiinput: "Enter name of allergies",
          namebiblabel: "Name on the BIB",
          namebibinput: "Enter a valid name on the BIB",
          ukuranbajulabel: "Clothes Size",
          paymentreceiptlabel: "Payment Confirmation Receipt",
     }
}
  